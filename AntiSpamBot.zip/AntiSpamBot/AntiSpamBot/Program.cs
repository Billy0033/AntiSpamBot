﻿using System;
using System.IO;
using System.Text.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using static System.Net.Mime.MediaTypeNames;
using System.Text;

class Program
{
    private static readonly string BotToken = "7547438624:AAEUTUI2L2bDm1Fv6cG9uNXwCcdEwXvRTk0";
    private static readonly long UserId = 5272975270;
    private static readonly string JsonFilePath = "spam.json";

    private static readonly TelegramBotClient Bot = new(BotToken);

    static async Task Main(string[] args)
    {
        Console.WriteLine("Бот запущен...");

        Bot.StartReceiving(
            HandleUpdateAsync,
            HandleErrorAsync
        );

        Console.ReadLine();
    }

    private static async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
    {
        // Проверяем, что это сообщение
        if (update.Message is not { } message)
            return;

        // Проверяем, что это личное сообщение от указанного пользователя
        if (message.Chat.Type != ChatType.Private || message.From.Id != UserId)
            return;

        // Получаем текст сообщения
        var messageText = message.Text;
        if (string.IsNullOrEmpty(messageText))
            return;

        // Формируем запись
        var newEntry = new MessageEntry
        {
            Id = message.MessageId,
            Text = messageText,
            Label = "spam"
        };

        // Сохраняем сообщение в JSON
        SaveMessageToJson(newEntry);

        // Отправляем ответ пользователю
        await botClient.SendTextMessageAsync(
            chatId: message.Chat.Id,
            text: "Сообщение сохранено и добавлено в JSON-файл.",
            cancellationToken: cancellationToken
        );
    }

    private static Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
    {
        var errorMessage = exception switch
        {
            ApiRequestException apiRequestException => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
            _ => exception.ToString()
        };

        Console.WriteLine(errorMessage);
        return Task.CompletedTask;
    }

    private static void SaveMessageToJson(MessageEntry messageEntry)
    {
        List<MessageEntry> messages;

        // Загружаем существующие сообщения из файла
        if (System.IO.File.Exists(JsonFilePath))
        {
            var json = System.IO.File.ReadAllText(JsonFilePath);
            messages = JsonSerializer.Deserialize<List<MessageEntry>>(json) ?? new List<MessageEntry>();
        }
        else
        {
            messages = new List<MessageEntry>();
        }

        // Добавляем новое сообщение
        messages.Add(messageEntry);

        // Сохраняем в файл
        var updatedJson = JsonSerializer.Serialize(messages, new JsonSerializerOptions { WriteIndented = true });
        //System.IO.File.WriteAllText(JsonFilePath, updatedJson); 
        System.IO.File.WriteAllText(JsonFilePath, updatedJson, Encoding.UTF8);

    }
}

// Модель для хранения сообщения
public class MessageEntry
{
    public int Id { get; set; }
    public string Text { get; set; }
    public string Label { get; set; }
}

